<?php

// Database Connectivity Configurations
$CN=mysqli_connect("localhost","uusqfgmy_amudhini","Amudhinidb@1","uusqfgmy_adn_bank");


?>
