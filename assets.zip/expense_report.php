<?php 
session_start(); 
require(dirname(__FILE__).DIRECTORY_SEPARATOR."Config.Admin.inc.php");

 include("include/header.php");
 include("include/header_top.php");
 include("include/left_menu.php");

 $employee_id='';
 $session_branch_id = $_SESSION['bid'];
 $session_role_id=$_SESSION['role_id'];
  
?>
<style>
.dataTables_filter label{
  text-align:left;
}
.dataTables_filter{
  text-align:right;
}
</style>
<?php if(isset($_GET['success']) && $_GET['success']){ $info=$_GET['success'];?>

<div class="alert alert-success alert-dismissible" style="margin:0 0 0 230px;width:100% !important"><?php echo  $info;?></div>

<?php } ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     <h3> Expense Report </h3>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="card card-info">
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header">
                <h3 class="card-title">Expense Report</h3>  
                  <!-- <button type="button" class="btn btn-primary float-right">
                  Large button
                  </button> -->
                  
                  <!-- <a class="btn-sm btn-success float-right" href="account_profile.php">Add New</a> -->
              </div>
            <?php
if($session_role_id == 1 || $session_role_id == 2 || $session_role_id == 9)
{
  $expense_details=select_data(EXPENSE_MASTER,"where status=2 ORDER BY expense_date ASC");
}
else{

  $expense_details=select_data(EXPENSE_MASTER,"where status=2 and branch_id='".$session_branch_id."' ORDER BY expense_date ASC");

}   ?>   
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                     <th>S No</th>
                    <th>Expense Type Name</th>
                    <th>Expense Amount</th>
                    <th>Expense Date</th>
                    <th>Comments</th>
                    <!-- <th>Action</th> -->
                  </tr>
                  </thead>
                  <tbody>
            <?php
              $i=1;
              foreach($expense_details as $ed)
              {
                $expense_date = $ed['expense_date'];
                $exp_date = date("d-m-Y", strtotime($expense_date));
                $expense_type_id = $ed['expense_type_id'];
                $expense_type_details=select_data(EXPENSE_TYPE_MASTER,"where expense_type_id='".$expense_type_id."'");
                $expense_type_name = $expense_type_details[0]['expense_type_name'];
                $expense_amt = $ed['expense_amount'];
                $comments = $ed['comments']; 
              ?>
              <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo  $expense_type_name; ?></td>
                  <td><?php echo  $expense_amt; ?></td>
                  <td><?php echo  $exp_date; ?></td>
                  <td><?php echo  $comments; ?></td>
                  

             
              </tr>
             <?php  $i++; } ?>
                  </tbody>
                 
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            </div>
            <!-- /.card -->

          </div>
          <!--/.col (left) -->
        
        
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>





 <?php include("include/footer.php"); ?>
 <?php include("include/footerjs.php"); ?>
</body>
</html>
