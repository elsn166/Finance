<?php

// Database Connectivity Configurations
$CN=mysqli_connect("localhost","uusqfgmy_demo","demo@2022","uusqfgmy_demo");


?>
