<footer class="main-footer">
    <div class="float-right hidden-xs">
      <b>Amuthini</b> 
    </div>
    <strong>Copyright &copy; 2021 <a href="">Amuthini</a>.</strong> All rights
    reserved.
  </footer>
