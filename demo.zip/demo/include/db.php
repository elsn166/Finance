<?php

$con=mysql_connect("localhost","debian-sys-maint","ytofQZcTyqgTGFxu");
mysql_select_db("society_bank",$con);

?>
