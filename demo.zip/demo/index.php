<?php session_start(); ?>
<?php

	header("Location:login.php");
	exit();


?>

